See the notes in TISN and TISID - this is just a quick port of both codes
to play a tune using both sound chips at the same time.

This is just a sample code.
