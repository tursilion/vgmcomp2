This one doesn't /quite/ fit on the Coleco with 1k of RAM - it's close, about 1088 bytes. But we only have 1024, and we need to save some of that for stack space.
