Wonderboy generates 6 channels:

0	ay
1	sn
2	sn
3	ay
4	ay
5	ay -> scale octave up for SN
